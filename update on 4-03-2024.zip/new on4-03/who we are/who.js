 // JavaScript functionality
 document.getElementById('toggleOfferBtn').addEventListener('click', function() {
  var offerSection = document.getElementById('offerSection');
  if (offerSection.style.display === 'none') {
    offerSection.style.display = 'block';
  } else {
    offerSection.style.display = 'none';
  }
});

// Simulating loading completion after 3 seconds
setTimeout(() => {
  document.getElementById('loading-container').classList.add('loading-hide');
}, 3000);
